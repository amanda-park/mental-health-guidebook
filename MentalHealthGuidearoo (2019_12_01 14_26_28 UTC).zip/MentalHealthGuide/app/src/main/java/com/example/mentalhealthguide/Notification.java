package com.example.mentalhealthguide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

//If I ever want to implement this reminder for people to do
//the activities in this guide - https://www.youtube.com/watch?v=ub4_f6ksxL0

public class Notification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
    }
}
